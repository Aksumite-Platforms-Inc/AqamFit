import 'package:flutter/material.dart';

class WorkoutCategoryGrid extends StatelessWidget {
  const WorkoutCategoryGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      padding: const EdgeInsets.all(16),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      children: [
        _CategoryCard(
          title: 'Chest Workouts',
          image: 'assets/images/chest.jpg',
          onTap: () {},
        ),
        _CategoryCard(
          title: 'Back Workouts',
          image: 'assets/images/back.jpg',
          onTap: () {},
        ),
        _CategoryCard(
          title: 'Leg Workouts',
          image: 'assets/images/legs.jpg',
          onTap: () {},
        ),
        _CategoryCard(
          title: 'Shoulder Workouts',
          image: 'assets/images/shoulders.jpg',
          onTap: () {},
        ),
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final String title;
  final String image;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.title,
    required this.image,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(image, fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
