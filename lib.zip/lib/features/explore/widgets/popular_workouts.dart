import 'package:flutter/material.dart';

class PopularWorkouts extends StatelessWidget {
  const PopularWorkouts({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox(); // TODO: Implement popular workouts list
  }
}
