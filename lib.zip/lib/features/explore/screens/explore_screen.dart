import 'package:flutter/material.dart';
import '../../../core/widgets/base_screen.dart';
import '../widgets/workout_category_grid.dart';
import '../widgets/popular_workouts.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      title: 'Explore',
      actions: [
        IconButton(
          icon: const Icon(Icons.search),
          onPressed: () {
            // TODO: Implement search
          },
        ),
      ],
      body: ListView(
        children: const [PopularWorkouts(), WorkoutCategoryGrid()],
      ),
    );
  }
}
