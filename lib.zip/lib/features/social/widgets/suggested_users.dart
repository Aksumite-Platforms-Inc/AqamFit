import 'package:flutter/material.dart';

class SuggestedUsers extends StatelessWidget {
  const SuggestedUsers({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(16.0),
      child: Text('Suggested Users'),
    );
  }
}
