import 'package:flutter/material.dart';
import '../../../core/widgets/base_screen.dart';
import '../widgets/workout_feed.dart';
import '../widgets/suggested_users.dart';

class SocialScreen extends StatelessWidget {
  const SocialScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      title: 'Social',
      actions: [
        IconButton(
          icon: const Icon(Icons.person_add_outlined),
          onPressed: () {
            // TODO: Implement add friend
          },
        ),
      ],
      body: ListView(children: const [SuggestedUsers(), WorkoutFeed()]),
    );
  }
}
