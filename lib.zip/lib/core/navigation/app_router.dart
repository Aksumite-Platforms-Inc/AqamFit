import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/workout/screens/workout_screen.dart';
import '../../features/explore/screens/explore_screen.dart';
import '../../features/progress/screens/progress_screen.dart';
import '../../features/social/screens/social_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/notifications/screens/notification_screen.dart';
import 'bottom_nav_bar.dart';

final GoRouter router = GoRouter(
  initialLocation: '/workout',
  routes: [
    GoRoute(
      path: '/',
      redirect: (BuildContext context, GoRouterState state) => '/workout',
    ),
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    ShellRoute(
      builder: (context, state, child) {
        // Get the current route name to determine which tab is active
        final location = state.uri.path;
        int currentIndex = 0;

        if (location.startsWith('/explore')) {
          currentIndex = 1;
        } else if (location.startsWith('/progress'))
          currentIndex = 2;
        else if (location.startsWith('/social'))
          currentIndex = 3;
        else if (location.startsWith('/profile'))
          currentIndex = 4;

        return Scaffold(
          body: child,
          bottomNavigationBar: BottomNavBar(currentIndex: currentIndex),
        );
      },
      routes: [
        GoRoute(
          path: '/workout',
          builder: (context, state) => const WorkoutScreen(),
        ),
        GoRoute(
          path: '/explore',
          builder: (context, state) => const ExploreScreen(),
        ),
        GoRoute(
          path: '/progress',
          builder: (context, state) => const ProgressScreen(),
        ),
        GoRoute(
          path: '/social',
          builder: (context, state) => const SocialScreen(),
        ),
        GoRoute(
          path: '/profile',
          builder: (context, state) => const ProfileScreen(),
        ),
      ],
    ),
    GoRoute(
      path: '/notifications',
      builder: (context, state) => const NotificationScreen(),
    ),
  ],
);
